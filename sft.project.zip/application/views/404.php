<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Page not found</title>
</head>

<body style="background-image: url(<?php echo base_url() ?>/assets/dist/img/404.jpg); background-size:cover; background-position:center;">
	<!-- <div style="padding-top: 500px;">
		<center><button onclick="goBack()" class="btn btn-danger">Back</button></center>
	</div>
	<script>
		function goBack() {
			window.history.back();
		}
	</script> -->

</body>

</html>